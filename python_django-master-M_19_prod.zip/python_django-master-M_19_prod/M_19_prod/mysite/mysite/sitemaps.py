from blogapp.sitemap import BlogSitemap

sitemaps = {
    "blog": BlogSitemap,
}
